export const segmentExistData = [
    {
        "segment_name": "last_10_days_blog_visits",
        "schema": [
            { "first_name": "First name" },
            { "last_name": "Last name" }
        ]
    },
    {
        "segment_name": "last_15_days_blog_visits",
        "schema": [
            { "first_name": "First name" },
            { "last_name": "Last name" }
        ]
    },
    {
        "segment_name": "last_18_days_blog_visits",
        "schema": [
            { "first_name": "First name" },
            { "last_name": "Last name" }
        ]
    },
    {
        "segment_name": "last_05_days_blog_visits",
        "schema": [
            { "first_name": "First name" },
            { "last_name": "Last name" }
        ]
    },
    {
        "segment_name": "last_07_days_blog_visits",
        "schema": [
            { "first_name": "First name" },
            { "last_name": "Last name" }
        ]
    },
    {
        "segment_name": "last_63_days_blog_visits",
        "schema": [
            { "first_name": "First name" },
            { "last_name": "Last name" }
        ]
    }

]