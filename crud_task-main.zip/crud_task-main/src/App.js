import { HomePage } from './pages'
import { Header } from './components'
function App() {
  return (
    <>
      <Header />
      <HomePage />
    </>

  );
}

export default App;
